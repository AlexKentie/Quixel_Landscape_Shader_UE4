If you make a complete new project:

1 - Put these two folders in your content folder before downloading quixel assets

or if you are already tweaking with quixel assets in an unreal project

1 - Go into your MSPresets folder and replace the MS_DefaultMaterial_Displacement folder with this one.
2 - Go into your Megascans/Surfaces folder and place the 
Material_Functions folder, 
Materials_Surface_Instances folder
and Material_Landscape_autoblend_paintable.uasset 

into this folder.
